let configr = {
  WWW_PORT: 3001,
};

module.exports = configr;
