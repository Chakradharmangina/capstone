let configr = {
  WWW_PORT: 3003,
  userServiceURL: "http://localhost:3001",
  adminServiceURL: "http://localhost:3002",
};

module.exports = configr;
