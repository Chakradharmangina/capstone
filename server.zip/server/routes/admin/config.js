let configr = {
  WWW_PORT: 3002,
};

module.exports = configr;
